# TravelCultr

**EPICS PROJECT**

**GROUP -25**

Members:

21BCG10006 Harshit Raj

21BCG10002 Sudhir Venkatesh

21BCG10014 Arin Goyal

21BCG10033 Pushkar Joshi

21BCE10912 Yash Ahuja

21BCE10751 Yash Saxena

21BEC10049 Pritam Das

21BCY10143 Mithun karthick

### PROJECT PICTURES:
![Screenshot (549)](https://github.com/Harshit-Raj-14/TravelCultr/assets/98808802/b21af84c-f672-4678-ae39-6aada1fbca66)
![Screenshot (548)](https://github.com/Harshit-Raj-14/TravelCultr/assets/98808802/259774c9-1646-4e08-bea0-0f044f9eb58e)
![Screenshot (547)](https://github.com/Harshit-Raj-14/TravelCultr/assets/98808802/0aa3a17c-3c02-45cc-86dc-60f796e8d87b)
![Screenshot (546)](https://github.com/Harshit-Raj-14/TravelCultr/assets/98808802/0042d010-b85a-4076-88f0-3451e2b40ffb)
![Screenshot 2024-05-08 at 09-25-44 EPICS Project -TravelCultr - EPICS Project -TravelCultr pdf](https://github.com/Harshit-Raj-14/TravelCultr/assets/98808802/64629c4a-f591-432f-b121-9078c2100bb3)
