// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDPO4t2GelPCWmDj-6Di8aS_pjt61EJ2WA",
  authDomain: "galleria-b5fda.firebaseapp.com",
  projectId: "galleria-b5fda",
  storageBucket: "galleria-b5fda.appspot.com",
  messagingSenderId: "1086049038593",
  appId: "1:1086049038593:web:5fb298108132d3ecc72b00"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;