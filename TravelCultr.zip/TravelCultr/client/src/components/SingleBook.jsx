import React from 'react'

const SingleBook = () => {
  return (
    <div>
      SingleBook
    </div>
  )
}

export default SingleBook
